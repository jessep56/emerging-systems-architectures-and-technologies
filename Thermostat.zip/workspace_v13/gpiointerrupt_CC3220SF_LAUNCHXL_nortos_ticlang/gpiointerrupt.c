/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// UART macro to send output to UART terminal
#define DISPLAY(x) UART2_write(uart, &output, x, NULL);

// Time intervals for task scheduling
#define CHECK_BUTTON_PERIOD 200
#define CHECK_TEMP_PERIOD 500
#define UPDATE_PERIOD 1000

// Global variables for task flags and status tracking
volatile unsigned char TimerFlag = 0;
volatile unsigned char Button0Flag = 0;
volatile unsigned char Button1Flag = 0;
I2C_Handle i2c;
UART2_Handle uart;
Timer_Handle timer0;
char output[64];
int temperature = 0;
int setPoint = 20;  // Initial set-point 20°C
int heatStatus = 0;
uint32_t seconds = 0;

// Sensor Data
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

/*
 *  ======== Timer Callback ========
 *  This function is called whenever the timer interrupt occurs.
 *  It sets the TimerFlag to signal the main loop to process tasks.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1;  // Set the timer flag
}

/*
 *  ======== GPIO Button Callback for Button 0 ========
 *  This function sets a flag when the button to increase temperature is pressed.
 */
void gpioButtonFxn0(uint_least8_t index) {
    Button0Flag = 1;  // Flag for button 0 press (increase temperature)
}

/*
 *  ======== GPIO Button Callback for Button 1 ========
 *  This function sets a flag when the button to decrease temperature is pressed.
 */
void gpioButtonFxn1(uint_least8_t index) {
    Button1Flag = 1;  // Flag for button 1 press (decrease temperature)
}

/*
 *  ======== UART Initialization ========
 *  This function initializes the UART2 module to enable communication via UART.
 */
void initUART(void) {
    UART2_Params uartParams;
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;  // Set baud rate to 115200
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL) {
        // Error: UART2_open() failed
        while (1);
    }
}

/*
 *  ======== I2C Initialization ========
 *  This function initializes the I2C driver and scans for the temperature sensor.
 */
void initI2C(void) {
    int8_t found = false;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;  // Set I2C bit rate to 400kHz
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1);
    }
    DISPLAY(snprintf(output, 32, "Passed\n\r"));
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    for (int i = 0; i < 3; ++i) {
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
        if (I2C_transfer(i2c, &i2cTransaction)) {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"));
    }
    if (!found) {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found\n\r"));
    }
}

/*
 *  ======== Timer Initialization ========
 *  This function initializes the timer to trigger interrupts every 100ms.
 */
void initTimer(void) {
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 100000;  // Set timer period to 100ms (100000us)
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;  // Set callback function
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL || Timer_start(timer0) == Timer_STATUS_ERROR) {
        // Error: Timer_start() failed
        while (1);
    }
}

/*
 *  ======== Read Temperature ========
 *  This function reads the temperature from the I2C temperature sensor and returns the value in °C.
 */
int16_t readTemp(void) {
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction)) {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;  // Convert sensor reading to degrees Celsius
        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;  // Sign extension for negative values
        }
    } else {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor\n\r"));
    }
    return temperature;
}

/*
 *  ======== Update Heater and LED Status ========
 *  This function checks if the heater should be on or off based on the temperature set-point
 *  and updates the LED and heat status accordingly.
 */
void updateHeatStatus(void) {
    if (temperature < setPoint) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn on LED (heater)
        heatStatus = 1;  // Heater is on
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Turn off LED (heater)
        heatStatus = 0;  // Heater is off
    }
}

/*
 *  ======== Main Thread (Task Scheduler) ========
 *  This is the main loop that schedules different tasks such as checking button presses,
 *  reading the temperature, and updating the heat status and UART output.
 */
void mainThread(void) {
    uint16_t timerCounter = 0;
    GPIO_init();
    initUART();
    initI2C();
    initTimer();

    // GPIO Button and LED initialization
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    // Initialize second button if available
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    DISPLAY(snprintf(output, 64, "Thermostat Initialized\n\r"));

    // Main task scheduler loop
    while (1) {
        // Check buttons every 200ms
        if (Button0Flag) {
            if (setPoint < 99) setPoint++;  // Increase set-point
            Button0Flag = 0;  // Reset flag
        }
        if (Button1Flag) {
            if (setPoint > 0) setPoint--;  // Decrease set-point
            Button1Flag = 0;  // Reset flag
        }

        // Read temperature every 500ms
        if (timerCounter % 5 == 0) {
            temperature = readTemp();  // Read from I2C temperature sensor
        }

        // Update heater status and UART output every 1 second
        if (timerCounter % 10 == 0) {
            updateHeatStatus();  // Update LED and heater status
            DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setPoint, heatStatus, seconds));
            seconds++;  // Increment the seconds counter
        }

        // Wait for the timer flag, raised every 100ms
        while (!TimerFlag) {}
        TimerFlag = 0;  // Reset the timer flag
        timerCounter++;  // Increment task scheduler counter
    }
}
